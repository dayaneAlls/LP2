﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (txtPeso.Text == "")
                txtPeso.Text = null;

            else 
                if (!double.TryParse(txtPeso.Text, out peso))
            {
                    MessageBox.Show("Digite seu peso");
                    txtPeso.Focus();
            }  
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (txtAltura.Text == "")
                txtAltura.Text = null;

            else 
                if (!double.TryParse(txtAltura.Text, out altura))
            {
                    MessageBox.Show("Digite sua altura");
                    txtAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtPeso.Text, out peso) && 
                double.TryParse(txtAltura.Text, out altura))
            {
                resultado = peso / (altura * altura);
                txtResultado.Text = Math.Round(resultado, 1).ToString();

                if (resultado < 18.5)
                {
                    txtClassificacao.Text = "Magreza | Obesidade(Grau): 0";
                }
                else if (resultado <= 24.9)
                {
                    txtClassificacao.Text = "Normal | Obesidade(Grau): 0";
                }
                else if (resultado <= 29.9)
                {
                    txtClassificacao.Text = "Sobrepeso | Obesidade(Grau): 1";
                }
                else if (resultado <= 39.9)
                {
                    txtClassificacao.Text = "Obesidade | Grau: 2";
                }
                else
                    txtClassificacao.Text = "Obesidade grave | Grau: 3";
            }
            else
                MessageBox.Show("Não é possível concluir o calculo\nDigite seu peso e sua altura");
                txtPeso.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtPeso.Text = "";
            txtResultado.Text = "";
            txtClassificacao.Text = "";
            txtPeso.Focus();
        }
    }
}
