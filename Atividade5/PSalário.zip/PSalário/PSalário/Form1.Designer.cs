﻿
namespace PSalário
{
    partial class frmFolhaPagamento
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblAliqInss = new System.Windows.Forms.Label();
            this.lblAliqIrpf = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnMasculino = new System.Windows.Forms.RadioButton();
            this.rbtnFeminino = new System.Windows.Forms.RadioButton();
            this.pnlCasado = new System.Windows.Forms.Panel();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtFilhos = new System.Windows.Forms.TextBox();
            this.txtAliqInss = new System.Windows.Forms.TextBox();
            this.txtAliqIrpf = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.lblDescInss = new System.Windows.Forms.Label();
            this.lblDescIrpf = new System.Windows.Forms.Label();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.txtDescInss = new System.Windows.Forms.TextBox();
            this.txtDescIrpf = new System.Windows.Forms.TextBox();
            this.lblDados = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.btnNovaConsulta = new System.Windows.Forms.Button();
            this.gbxSexo.SuspendLayout();
            this.pnlCasado.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.BackColor = System.Drawing.Color.Transparent;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(33, 68);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(187, 25);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome funcionário:";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.BackColor = System.Drawing.Color.Transparent;
            this.lblSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalario.Location = new System.Drawing.Point(33, 116);
            this.lblSalario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(144, 25);
            this.lblSalario.TabIndex = 1;
            this.lblSalario.Text = "Salário Bruto:";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.BackColor = System.Drawing.Color.Transparent;
            this.lblFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilhos.Location = new System.Drawing.Point(33, 156);
            this.lblFilhos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(181, 25);
            this.lblFilhos.TabIndex = 2;
            this.lblFilhos.Text = "Número de filhos:";
            // 
            // lblAliqInss
            // 
            this.lblAliqInss.AutoSize = true;
            this.lblAliqInss.BackColor = System.Drawing.Color.Transparent;
            this.lblAliqInss.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliqInss.ForeColor = System.Drawing.Color.Black;
            this.lblAliqInss.Location = new System.Drawing.Point(34, 314);
            this.lblAliqInss.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliqInss.Name = "lblAliqInss";
            this.lblAliqInss.Size = new System.Drawing.Size(155, 25);
            this.lblAliqInss.TabIndex = 3;
            this.lblAliqInss.Text = "Alíquota INSS:";
            // 
            // lblAliqIrpf
            // 
            this.lblAliqIrpf.AutoSize = true;
            this.lblAliqIrpf.BackColor = System.Drawing.Color.Transparent;
            this.lblAliqIrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliqIrpf.Location = new System.Drawing.Point(33, 357);
            this.lblAliqIrpf.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliqIrpf.Name = "lblAliqIrpf";
            this.lblAliqIrpf.Size = new System.Drawing.Size(151, 25);
            this.lblAliqIrpf.TabIndex = 4;
            this.lblAliqIrpf.Text = "Alíquota IRPF:";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.BackColor = System.Drawing.Color.Transparent;
            this.lblSalLiquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalLiquido.Location = new System.Drawing.Point(359, 403);
            this.lblSalLiquido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(163, 25);
            this.lblSalLiquido.TabIndex = 6;
            this.lblSalLiquido.Text = "Salário Liquido:";
            // 
            // gbxSexo
            // 
            this.gbxSexo.BackColor = System.Drawing.Color.Transparent;
            this.gbxSexo.Controls.Add(this.rbtnMasculino);
            this.gbxSexo.Controls.Add(this.rbtnFeminino);
            this.gbxSexo.Location = new System.Drawing.Point(625, 66);
            this.gbxSexo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbxSexo.Size = new System.Drawing.Size(185, 123);
            this.gbxSexo.TabIndex = 7;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // rbtnMasculino
            // 
            this.rbtnMasculino.AutoSize = true;
            this.rbtnMasculino.BackColor = System.Drawing.Color.PaleGreen;
            this.rbtnMasculino.Location = new System.Drawing.Point(26, 76);
            this.rbtnMasculino.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rbtnMasculino.Name = "rbtnMasculino";
            this.rbtnMasculino.Size = new System.Drawing.Size(122, 29);
            this.rbtnMasculino.TabIndex = 1;
            this.rbtnMasculino.Text = "Masculino";
            this.rbtnMasculino.UseVisualStyleBackColor = false;
            // 
            // rbtnFeminino
            // 
            this.rbtnFeminino.AutoSize = true;
            this.rbtnFeminino.BackColor = System.Drawing.Color.PaleGreen;
            this.rbtnFeminino.Checked = true;
            this.rbtnFeminino.Location = new System.Drawing.Point(26, 40);
            this.rbtnFeminino.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rbtnFeminino.Name = "rbtnFeminino";
            this.rbtnFeminino.Size = new System.Drawing.Size(113, 29);
            this.rbtnFeminino.TabIndex = 0;
            this.rbtnFeminino.TabStop = true;
            this.rbtnFeminino.Text = "Feminino";
            this.rbtnFeminino.UseVisualStyleBackColor = false;
            // 
            // pnlCasado
            // 
            this.pnlCasado.BackColor = System.Drawing.Color.Transparent;
            this.pnlCasado.Controls.Add(this.ckbxCasado);
            this.pnlCasado.ForeColor = System.Drawing.Color.Black;
            this.pnlCasado.Location = new System.Drawing.Point(626, 194);
            this.pnlCasado.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlCasado.Name = "pnlCasado";
            this.pnlCasado.Size = new System.Drawing.Size(184, 61);
            this.pnlCasado.TabIndex = 8;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.BackColor = System.Drawing.Color.LightGreen;
            this.ckbxCasado.Location = new System.Drawing.Point(25, 19);
            this.ckbxCasado.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(103, 29);
            this.ckbxCasado.TabIndex = 0;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = false;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(221, 67);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(393, 30);
            this.txtNome.TabIndex = 1;
            this.txtNome.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtNome.Validated += new System.EventHandler(this.txtNome_Validated);
            // 
            // txtFilhos
            // 
            this.txtFilhos.Location = new System.Drawing.Point(220, 155);
            this.txtFilhos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtFilhos.Name = "txtFilhos";
            this.txtFilhos.Size = new System.Drawing.Size(81, 30);
            this.txtFilhos.TabIndex = 3;
            this.txtFilhos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtFilhos.Validated += new System.EventHandler(this.txtFilhos_Validated);
            // 
            // txtAliqInss
            // 
            this.txtAliqInss.Location = new System.Drawing.Point(195, 311);
            this.txtAliqInss.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtAliqInss.Name = "txtAliqInss";
            this.txtAliqInss.ReadOnly = true;
            this.txtAliqInss.Size = new System.Drawing.Size(106, 30);
            this.txtAliqInss.TabIndex = 11;
            this.txtAliqInss.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtAliqIrpf
            // 
            this.txtAliqIrpf.Location = new System.Drawing.Point(195, 357);
            this.txtAliqIrpf.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtAliqIrpf.Name = "txtAliqIrpf";
            this.txtAliqIrpf.ReadOnly = true;
            this.txtAliqIrpf.Size = new System.Drawing.Size(104, 30);
            this.txtAliqIrpf.TabIndex = 12;
            this.txtAliqIrpf.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Location = new System.Drawing.Point(194, 403);
            this.txtSalFamilia.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.ReadOnly = true;
            this.txtSalFamilia.Size = new System.Drawing.Size(106, 30);
            this.txtSalFamilia.TabIndex = 13;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Location = new System.Drawing.Point(527, 403);
            this.txtSalLiquido.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.ReadOnly = true;
            this.txtSalLiquido.Size = new System.Drawing.Size(159, 30);
            this.txtSalLiquido.TabIndex = 14;
            // 
            // lblDescInss
            // 
            this.lblDescInss.AutoSize = true;
            this.lblDescInss.BackColor = System.Drawing.Color.Transparent;
            this.lblDescInss.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescInss.Location = new System.Drawing.Point(359, 312);
            this.lblDescInss.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescInss.Name = "lblDescInss";
            this.lblDescInss.Size = new System.Drawing.Size(167, 25);
            this.lblDescInss.TabIndex = 15;
            this.lblDescInss.Text = "Desconto INSS:";
            // 
            // lblDescIrpf
            // 
            this.lblDescIrpf.AutoSize = true;
            this.lblDescIrpf.BackColor = System.Drawing.Color.Transparent;
            this.lblDescIrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescIrpf.Location = new System.Drawing.Point(359, 357);
            this.lblDescIrpf.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescIrpf.Name = "lblDescIrpf";
            this.lblDescIrpf.Size = new System.Drawing.Size(163, 25);
            this.lblDescIrpf.TabIndex = 16;
            this.lblDescIrpf.Text = "Desconto IRPF:";
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(221, 112);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(169, 30);
            this.txtSalario.TabIndex = 2;
            this.txtSalario.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSalario.Validated += new System.EventHandler(this.txtSalario_Validated);
            // 
            // btnVerificar
            // 
            this.btnVerificar.BackColor = System.Drawing.Color.ForestGreen;
            this.btnVerificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar.ForeColor = System.Drawing.Color.White;
            this.btnVerificar.Location = new System.Drawing.Point(273, 204);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(277, 48);
            this.btnVerificar.TabIndex = 4;
            this.btnVerificar.Text = "Verificar Desconto";
            this.btnVerificar.UseVisualStyleBackColor = false;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // txtDescInss
            // 
            this.txtDescInss.Location = new System.Drawing.Point(527, 311);
            this.txtDescInss.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtDescInss.Name = "txtDescInss";
            this.txtDescInss.ReadOnly = true;
            this.txtDescInss.Size = new System.Drawing.Size(106, 30);
            this.txtDescInss.TabIndex = 19;
            // 
            // txtDescIrpf
            // 
            this.txtDescIrpf.Location = new System.Drawing.Point(527, 356);
            this.txtDescIrpf.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtDescIrpf.Name = "txtDescIrpf";
            this.txtDescIrpf.ReadOnly = true;
            this.txtDescIrpf.Size = new System.Drawing.Size(106, 30);
            this.txtDescIrpf.TabIndex = 20;
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.BackColor = System.Drawing.Color.Transparent;
            this.lblDados.Location = new System.Drawing.Point(54, 266);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(85, 25);
            this.lblDados.TabIndex = 21;
            this.lblDados.Text = "lbldados";
            this.lblDados.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDados.Visible = false;
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.BackColor = System.Drawing.Color.Transparent;
            this.lblSalFamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalFamilia.Location = new System.Drawing.Point(32, 403);
            this.lblSalFamilia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(162, 25);
            this.lblSalFamilia.TabIndex = 22;
            this.lblSalFamilia.Text = "Salário Família:";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.Color.ForestGreen;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lblTitulo.Location = new System.Drawing.Point(250, 9);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(336, 38);
            this.lblTitulo.TabIndex = 23;
            this.lblTitulo.Text = "Folha de Pagamento";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnNovaConsulta
            // 
            this.btnNovaConsulta.BackColor = System.Drawing.Color.ForestGreen;
            this.btnNovaConsulta.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovaConsulta.ForeColor = System.Drawing.Color.White;
            this.btnNovaConsulta.Location = new System.Drawing.Point(313, 458);
            this.btnNovaConsulta.Name = "btnNovaConsulta";
            this.btnNovaConsulta.Size = new System.Drawing.Size(209, 47);
            this.btnNovaConsulta.TabIndex = 24;
            this.btnNovaConsulta.Text = "Nova Consulta";
            this.btnNovaConsulta.UseVisualStyleBackColor = false;
            this.btnNovaConsulta.Click += new System.EventHandler(this.btnNovaConsulta_Click);
            // 
            // frmFolhaPagamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.BackgroundImage = global::PSalário.Properties.Resources.papel_de_parede_muresco_disney_2033_3;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(845, 517);
            this.Controls.Add(this.btnNovaConsulta);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.txtDescIrpf);
            this.Controls.Add(this.txtDescInss);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.lblDescIrpf);
            this.Controls.Add(this.lblDescInss);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliqIrpf);
            this.Controls.Add(this.txtAliqInss);
            this.Controls.Add(this.txtFilhos);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.pnlCasado);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblAliqIrpf);
            this.Controls.Add(this.lblAliqInss);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblNome);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmFolhaPagamento";
            this.Text = "Folha de Pagamento";
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            this.pnlCasado.ResumeLayout(false);
            this.pnlCasado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblAliqInss;
        private System.Windows.Forms.Label lblAliqIrpf;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.RadioButton rbtnMasculino;
        private System.Windows.Forms.RadioButton rbtnFeminino;
        private System.Windows.Forms.Panel pnlCasado;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtFilhos;
        private System.Windows.Forms.TextBox txtAliqInss;
        private System.Windows.Forms.TextBox txtAliqIrpf;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.Label lblDescInss;
        private System.Windows.Forms.Label lblDescIrpf;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.TextBox txtDescInss;
        private System.Windows.Forms.TextBox txtDescIrpf;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnNovaConsulta;
    }
}

