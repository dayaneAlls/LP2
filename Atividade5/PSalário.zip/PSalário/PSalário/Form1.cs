﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalário
{
    public partial class frmFolhaPagamento : Form
    {
        double salarioBruto, numFilho;
        string nome;
        public frmFolhaPagamento()
        {
            InitializeComponent();
        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Nome vazio\nInforme o nome");
                txtNome.Focus();
            }
            else 
                nome = Convert.ToString(txtNome.Text);
        }

        private void txtSalario_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtSalario.Text, out salarioBruto))
            {
                MessageBox.Show("Informe o salário!");
                txtSalario.Text = null;
                txtSalario.Focus();
            }
            else if (salarioBruto <= 0)
            {
                MessageBox.Show("Salário não pode ser menor ou igual a zero!");
                txtSalario.Text = null;
                txtSalario.Focus();
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double descontoINSS;
            double descontoIRPF;
            double salarioFamilia=0;
            double salarioLiquido;

            if (double.TryParse(txtSalario.Text, out salarioBruto)) 
            {
                if (salarioBruto <= 800.47)
                {
                    txtAliqInss.Text = "7.65%";
                    descontoINSS = 0.0765 * salarioBruto;
                    txtDescInss.Text = "R$  " + descontoINSS.ToString("N2");
                }
                else if (salarioBruto <= 1050)
                {
                    txtAliqInss.Text = "8.65%";
                    descontoINSS = 0.0865 * salarioBruto;
                    txtDescInss.Text = "R$  " + descontoINSS.ToString("N2");
                }
                else if (salarioBruto <= 1400.77)
                {
                    txtAliqInss.Text = "9.00%";
                    descontoINSS = 0.09 * salarioBruto;
                    txtDescInss.Text = "R$  " + descontoINSS.ToString("N2");
                }
                else if (salarioBruto <= 2801.56)
                {
                    txtAliqInss.Text = "11.00%";
                    descontoINSS = 0.11 * salarioBruto;
                    txtDescInss.Text = "R$  " + descontoINSS.ToString("N2");
                }
                else
                {
                    txtAliqInss.Text = "Teto";
                    descontoINSS = 308.17;
                    txtDescInss.Text = "R$  " + descontoINSS.ToString("N2");
                }

                if (salarioBruto <= 1257.12)
                {
                    txtAliqIrpf.Text = "Isento";
                    descontoIRPF = 0;
                    txtDescIrpf.Text = "R$  " + descontoIRPF.ToString("N2");
                }
                else if (salarioBruto <= 2512.08)
                {
                    txtAliqIrpf.Text = "15.00%";
                    descontoIRPF = 0.15 * salarioBruto;
                    txtDescIrpf.Text = "R$  " + descontoIRPF.ToString("N2");
                }
                else
                {
                    txtAliqIrpf.Text = "27.5%";
                    descontoIRPF = 0.275 * salarioBruto;
                    txtDescIrpf.Text = "R$  " + descontoIRPF.ToString("N2");
                }

                if (salarioBruto <= 435.52)
                {
                    salarioFamilia = 22.33 * numFilho;
                    txtSalFamilia.Text = "R$  " + salarioFamilia.ToString("N2");
                }
                else if (salarioBruto <= 654.61)
                {
                    salarioFamilia = 15.74 * numFilho;
                    txtSalFamilia.Text = "R$  " + salarioFamilia.ToString("N2");
                }
                else
                    txtSalFamilia.Text = "R$  " + salarioFamilia.ToString("N2");

                salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                txtSalLiquido.Text = "R$  " + salarioLiquido.ToString("N2");

                lblDados.Visible = true;

                if (rbtnFeminino.Checked)
                {
                    lblDados.Text = "Os descontos do salário da Sra(ta). " + nome;
                }
                else 
                     lblDados.Text = "Os descontos do salário do Sr. " + nome;
                

                if (ckbxCasado.Checked)
                {
                    lblDados.Text += " que é Casado(a)";
                }
                else
                    lblDados.Text += " que é Solteiro(a)";

                if (txtFilhos.Text == "")
                {
                    lblDados.Text += " e sem filhos são:";
                }
                else
                    lblDados.Text += " e que tem " + numFilho + " filho(s) são:";
            }
            else
            {
                MessageBox.Show("Informe o salário");
                txtSalario.Focus();
            }
        }

        private void btnNovaConsulta_Click(object sender, EventArgs e)
        {
            txtNome.Text = "";
            txtSalario.Text = "";
            txtFilhos.Text = "";
            txtAliqInss.Text = "";
            txtAliqIrpf.Text = "";
            txtSalFamilia.Text = "";
            txtDescInss.Text = "";
            txtDescIrpf.Text = "";
            txtSalLiquido.Text = "";
            lblDados.Text = "";
            txtNome.Focus();
        }

        private void txtFilhos_Validated(object sender, EventArgs e)
        {
            if (txtFilhos.Text == "")
            {
                numFilho = 0;
            }
            else if (!double.TryParse(txtFilhos.Text, out numFilho))
            {
                MessageBox.Show("Números inválidos!\nInforme números.");
                txtFilhos.Text = null;
                txtFilhos.Focus();
            }
            else if (numFilho < 0)
            {
                MessageBox.Show("Informe um número maior ou igual a zero");
                txtFilhos.Text = null;
                txtFilhos.Focus();
            }

        }
    }
}
