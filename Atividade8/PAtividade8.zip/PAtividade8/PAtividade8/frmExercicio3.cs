﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string texto = txtFrase.Text.ToLower();
            String com = "äáâàãéêëèíîïìöóôòõüúûùç";
            String sem = "aaaaaeeeeiiiiooooouuuuc";

            if (txtFrase.Text == "")
            {
                MessageBox.Show("O campo 'frase' está vazio!\nDigite uma frase.");
                txtFrase.Focus();
            }
            else
            {
                for (int i = 0; i < texto.Length; i++)
                {
                    if (char.IsWhiteSpace(texto, i))
                        texto = texto.Remove(i, 1);
                }
                for (int x= 0; x < com.Length; x++)
                {
                     texto = texto.Replace(com[x], sem[x]);
                }
                string frase = texto;
                char [] arr = frase.ToCharArray();
                Array.Reverse(arr);
                frase = "";
                foreach (char c in arr)
                {
                    frase += c.ToString();
                }

                if (String.Equals(frase, texto))
                    MessageBox.Show("A Frase: '"+txtFrase.Text.ToString()+"'-> é um palíndromo");
                else
                    MessageBox.Show("A Frase: '"+txtFrase.Text.ToString()+"'-> não é um palíndromo");
            }
        }
    }
}
