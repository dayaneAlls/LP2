﻿
namespace ProjetoTriângulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblLado1 = new System.Windows.Forms.Label();
            this.lblLado2 = new System.Windows.Forms.Label();
            this.lblLado3 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtLado1 = new System.Windows.Forms.TextBox();
            this.txtLado2 = new System.Windows.Forms.TextBox();
            this.txtLado3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.Color.Transparent;
            this.lblTitulo.Font = new System.Drawing.Font("Mongolian Baiti", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.Navy;
            this.lblTitulo.Location = new System.Drawing.Point(32, 44);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(462, 40);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Calcular lados do triângulo";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLado1
            // 
            this.lblLado1.AutoSize = true;
            this.lblLado1.BackColor = System.Drawing.Color.Transparent;
            this.lblLado1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLado1.ForeColor = System.Drawing.Color.Black;
            this.lblLado1.Location = new System.Drawing.Point(146, 113);
            this.lblLado1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLado1.Name = "lblLado1";
            this.lblLado1.Size = new System.Drawing.Size(99, 29);
            this.lblLado1.TabIndex = 9;
            this.lblLado1.Text = "Lado 1:";
            // 
            // lblLado2
            // 
            this.lblLado2.AutoSize = true;
            this.lblLado2.BackColor = System.Drawing.Color.Transparent;
            this.lblLado2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLado2.Location = new System.Drawing.Point(145, 167);
            this.lblLado2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLado2.Name = "lblLado2";
            this.lblLado2.Size = new System.Drawing.Size(99, 29);
            this.lblLado2.TabIndex = 10;
            this.lblLado2.Text = "Lado 2:";
            // 
            // lblLado3
            // 
            this.lblLado3.AutoSize = true;
            this.lblLado3.BackColor = System.Drawing.Color.Transparent;
            this.lblLado3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLado3.ForeColor = System.Drawing.Color.Black;
            this.lblLado3.Location = new System.Drawing.Point(145, 222);
            this.lblLado3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLado3.Name = "lblLado3";
            this.lblLado3.Size = new System.Drawing.Size(99, 29);
            this.lblLado3.TabIndex = 8;
            this.lblLado3.Text = "Lado 3:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.MediumTurquoise;
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(167, 283);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(166, 52);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtLado1
            // 
            this.txtLado1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txtLado1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLado1.ForeColor = System.Drawing.Color.Black;
            this.txtLado1.Location = new System.Drawing.Point(248, 111);
            this.txtLado1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtLado1.Name = "txtLado1";
            this.txtLado1.Size = new System.Drawing.Size(95, 34);
            this.txtLado1.TabIndex = 1;
            this.txtLado1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtLado1.Validated += new System.EventHandler(this.txtLado1_Validated);
            // 
            // txtLado2
            // 
            this.txtLado2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txtLado2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLado2.ForeColor = System.Drawing.Color.Black;
            this.txtLado2.Location = new System.Drawing.Point(248, 167);
            this.txtLado2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtLado2.Name = "txtLado2";
            this.txtLado2.Size = new System.Drawing.Size(95, 34);
            this.txtLado2.TabIndex = 2;
            this.txtLado2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtLado2.Validated += new System.EventHandler(this.txtLado2_Validated);
            // 
            // txtLado3
            // 
            this.txtLado3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txtLado3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLado3.ForeColor = System.Drawing.Color.Black;
            this.txtLado3.Location = new System.Drawing.Point(248, 219);
            this.txtLado3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtLado3.Name = "txtLado3";
            this.txtLado3.Size = new System.Drawing.Size(95, 34);
            this.txtLado3.TabIndex = 3;
            this.txtLado3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtLado3.Validated += new System.EventHandler(this.txtLado3_Validated);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ProjetoTriângulo.Properties.Resources.papel_de_parede_geometrico_triangulos_azuis;
            this.ClientSize = new System.Drawing.Size(522, 374);
            this.Controls.Add(this.txtLado3);
            this.Controls.Add(this.txtLado2);
            this.Controls.Add(this.txtLado1);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblLado3);
            this.Controls.Add(this.lblLado2);
            this.Controls.Add(this.lblLado1);
            this.Controls.Add(this.lblTitulo);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Calcular lados do triângulo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblLado1;
        private System.Windows.Forms.Label lblLado2;
        private System.Windows.Forms.Label lblLado3;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtLado1;
        private System.Windows.Forms.TextBox txtLado2;
        private System.Windows.Forms.TextBox txtLado3;
    }
}

