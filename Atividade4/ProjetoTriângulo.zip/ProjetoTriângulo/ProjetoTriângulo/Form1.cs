﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoTriângulo
{
    public partial class Form1 : Form
    {
        double lado1, lado2, lado3;

        private void txtLado2_Validated(object sender, EventArgs e)
        {
            if (txtLado2.Text == "")
                txtLado2.Text = null;

            else if (!double.TryParse(txtLado2.Text, out lado2))
            {
                     MessageBox.Show("Números inválidos!");
                     txtLado2.Text = null;
                     txtLado2.Focus();
            }
            else
                if (lado2 <= 0)
                MessageBox.Show("Digite um número maior que zero");
        }

        private void txtLado3_Validated(object sender, EventArgs e)
        {
            if (txtLado3.Text == "")
                txtLado3.Text = null;

            else if (!double.TryParse(txtLado3.Text, out lado3))
            {
                     MessageBox.Show("Números inválidos!");
                     txtLado3.Text = null;
                     txtLado3.Focus();
            }
            else
                if (lado3 <= 0)
                MessageBox.Show("Digite um número maior que zero");
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if(double.TryParse(txtLado1.Text, out lado1) &&
               double.TryParse(txtLado2.Text, out lado2) &&
               double.TryParse(txtLado3.Text, out lado3))
            {
                if((lado1 - lado3) < lado1 && lado1 < (lado2 + lado3) &&
                   (lado1 - lado3) < lado2 && lado2 < (lado1 + lado3) &&
                   (lado3 - lado2) < lado3 && lado3 < (lado1 + lado2))
                {
                    if(lado1 == lado2 && lado1 == lado3 && lado2 == lado3)
                    {
                        MessageBox.Show("Triângulo Equilátero");
                    }
                    else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3)
                    {
                        MessageBox.Show("Triângulo Isósceles");
                    }
                    else
                        MessageBox.Show("Triângulo Escaleno");
                }
                else
                    MessageBox.Show("Os números digitados não formam um triângulo\nTente Novamente");
                    txtLado1.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLado1_Validated(object sender, EventArgs e)
        {
            if (txtLado1.Text == "")
             txtLado1.Text = null;

            else if (!double.TryParse(txtLado1.Text, out lado1))
            {
                     MessageBox.Show("Números inválidos!");
                     txtLado1.Text = null;
                     txtLado1.Focus();
            }
            else if (lado1 <= 0)
                MessageBox.Show("Digite um número maior que zero");
        }
    }
}
