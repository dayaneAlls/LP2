﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class frmPVendas : Form
    {
        public frmPVendas()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string auxiliarValor="";
            double soma = 0;
            double totalGeral = 0;
            double[,] totais = new double[2, 4];
            double[] valores = new double[2];

            lstbxDados.Items.Clear();

            for (int i = 0; i < 2; i++)
            {
                for (int x = 0; x < 4; x++)
                {
                    auxiliarValor = Interaction.InputBox("Digite o total de vendas da semana " + (x + 1) + " do mês " + (i + 1), "Total de vendas mensais");
                    if (auxiliarValor == "")
                        break;
                    if (!double.TryParse(auxiliarValor, out totais[i, x]))
                    {
                        MessageBox.Show("Valor Inválido!");
                        x -= 1;
                    }
                    else if (totais[i, x] < 0)
                    {
                        MessageBox.Show("O valor não pode ser menor que zero");
                        x -= 1;
                    }
                    else
                    {
                        soma += totais[i, x];
                        totalGeral += totais[i, x];
                        lstbxDados.Items.Add("\nTotal do mês: " + (i + 1) + "  Semana: " + (x + 1) + " " + totais[i, x].ToString("C2"));
                    }
                }
                lstbxDados.Items.Add(">> Total Mês: " + soma.ToString("C2"));
                lstbxDados.Items.Add("----------------------------------");

                if (auxiliarValor == "")
                    break;

                soma = 0;
            }
            lstbxDados.Items.Add(">> Total Geral: " + totalGeral.ToString("C2"));
        }
    }
}
