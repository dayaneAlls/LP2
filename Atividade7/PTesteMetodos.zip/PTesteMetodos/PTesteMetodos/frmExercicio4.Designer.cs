﻿
namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.lblFrase = new System.Windows.Forms.Label();
            this.btnContNumero = new System.Windows.Forms.Button();
            this.btnPosicaoEspaco = new System.Windows.Forms.Button();
            this.btnContLetra = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchtxtFrase.Location = new System.Drawing.Point(186, 38);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(272, 122);
            this.rchtxtFrase.TabIndex = 1;
            this.rchtxtFrase.Text = "";
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFrase.Location = new System.Drawing.Point(2, 38);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(163, 25);
            this.lblFrase.TabIndex = 1;
            this.lblFrase.Text = "Digite uma frase: ";
            this.lblFrase.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnContNumero
            // 
            this.btnContNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContNumero.Location = new System.Drawing.Point(29, 176);
            this.btnContNumero.Name = "btnContNumero";
            this.btnContNumero.Size = new System.Drawing.Size(138, 77);
            this.btnContNumero.TabIndex = 2;
            this.btnContNumero.Text = "Conta Números";
            this.btnContNumero.UseVisualStyleBackColor = true;
            this.btnContNumero.Click += new System.EventHandler(this.btnContNumero_Click);
            // 
            // btnPosicaoEspaco
            // 
            this.btnPosicaoEspaco.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPosicaoEspaco.Location = new System.Drawing.Point(186, 176);
            this.btnPosicaoEspaco.Name = "btnPosicaoEspaco";
            this.btnPosicaoEspaco.Size = new System.Drawing.Size(138, 77);
            this.btnPosicaoEspaco.TabIndex = 3;
            this.btnPosicaoEspaco.Text = "Mostra Posições de Espaços";
            this.btnPosicaoEspaco.UseVisualStyleBackColor = true;
            this.btnPosicaoEspaco.Click += new System.EventHandler(this.btnPosicaoEspaco_Click);
            // 
            // btnContLetra
            // 
            this.btnContLetra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContLetra.Location = new System.Drawing.Point(341, 176);
            this.btnContLetra.Name = "btnContLetra";
            this.btnContLetra.Size = new System.Drawing.Size(138, 77);
            this.btnContLetra.TabIndex = 4;
            this.btnContLetra.Text = "Conta Letras";
            this.btnContLetra.UseVisualStyleBackColor = true;
            this.btnContLetra.Click += new System.EventHandler(this.btnContLetra_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 379);
            this.Controls.Add(this.btnContLetra);
            this.Controls.Add(this.btnPosicaoEspaco);
            this.Controls.Add(this.btnContNumero);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Label lblFrase;
        private System.Windows.Forms.Button btnContNumero;
        private System.Windows.Forms.Button btnPosicaoEspaco;
        private System.Windows.Forms.Button btnContLetra;
    }
}