﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContNumero_Click(object sender, EventArgs e)
        {
            int cont = 0;
            if (rchtxtFrase.Text == "")
            {
                MessageBox.Show("O campo está vazio!\nDigite uma frase");
                rchtxtFrase.Focus();
            }
            else
            {
                for (int i = 0; i < rchtxtFrase.Text.Length; i++)
                {
                    if (char.IsNumber(rchtxtFrase.Text, i))
                    {
                        cont++;
                    }
                }

                if (cont == 0)
                    MessageBox.Show("O texto não possui números");
                else
                    MessageBox.Show("O texto possui " + cont.ToString() + " números");
            }
        }

        private void btnPosicaoEspaco_Click(object sender, EventArgs e)
        {
            string texto = rchtxtFrase.Text.Trim();
            int tamanho = texto.Length;
            int total = 0;
            int contador = 0;
  
            if (rchtxtFrase.Text == "")
            {
                MessageBox.Show("O campo está vazio!\nDigite uma frase");
                rchtxtFrase.Focus();
            }
            else
            { 

                while (contador<tamanho)
                {
                    if (!char.IsWhiteSpace(rchtxtFrase.Text, total))
                    {
                        total += 1;
                    }
                    contador += 1;
                }
                MessageBox.Show("O primeiro caractere em branco do texto está na posição " + total.ToString());
            }
        }

        private void btnContLetra_Click(object sender, EventArgs e)
        {
            int i = 0;
            if (rchtxtFrase.Text == "")
            {
                MessageBox.Show("O campo está vazio!\nDigite uma frase");
                rchtxtFrase.Focus();
            }
            else
            {
                foreach (char letra in rchtxtFrase.Text)
                {
                    if(char.IsLetter(rchtxtFrase.Text, i))
                    i++;
                }
                MessageBox.Show("O texto possui " + i.ToString() + " caracteres alfabéticos");
            }
        }
    }
}
