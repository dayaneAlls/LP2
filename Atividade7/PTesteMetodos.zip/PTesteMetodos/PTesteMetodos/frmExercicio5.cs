﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        int num1, num2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int sorteio = 0;
            Random auxiliar = new Random();
            if (num1 > num2)
                MessageBox.Show("O número 1 não pode ser maior do que o segundo número!");
            else if (num1 == num2)
                MessageBox.Show("Os dois números devem ser diferentes!");
            else
            {
                sorteio = auxiliar.Next(num1, num2);
                MessageBox.Show("O número sorteado é: " + sorteio.ToString());
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (txtNumero2.Text == "")
            {
                MessageBox.Show("O campo número 2 está vazio!\nDigite um número.");
                txtNumero2.Focus();
            }
            else if (!int.TryParse(txtNumero2.Text, out num2))
            {
                MessageBox.Show("Digite apenas números");
                txtNumero2.Text = null;
                txtNumero2.Focus();
            }
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (txtNumero1.Text == "")
            {
                MessageBox.Show("O campo número 1 está vazio!\nDigite um número.");
                txtNumero1.Focus();
            }
            else if (!int.TryParse(txtNumero1.Text, out num1))
            {
                MessageBox.Show("Digite apenas números");
                txtNumero1.Text = null;
                txtNumero1.Focus();
            }        
        }
    }
}
